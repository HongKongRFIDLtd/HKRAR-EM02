﻿#define EM02
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Globalization;
using System.Reflection;
using System.Diagnostics;

namespace Demo
{
    public partial class Form1 : Form
    {
        HKRFID.Active.HKRAREM TT;

        DataTable dtTagID = null;
        DataTable dtViewBuffer = null;
        
        private Thread runThread;
        private bool update = false;
        private DateTime CompareTime , UpdateTime;
        int AccTagCount;
        int TagCount;

        public Form1()
        {
            InitializeComponent();
            Init();
        }
        private void Init()
        {
            tableLayoutPanel3.Enabled = false;
            TagCount = 0;
            //comboBox1.Enabled = false;
            dtTagID = new DataTable();
            dtViewBuffer = new DataTable();
            CompareTime = DateTime.Now;
            UpdateTime = DateTime.Now;
            dtTagID.Columns.Add("TagID");
            dtTagID.Columns.Add("Count");
            dtTagID.Columns.Add("Type");
            dtTagID.Columns.Add("Signal_Strength");
            dtTagID.Columns.Add("Battery_Status");
            dtTagID.Columns.Add("Last_Updated");
#if(EM02)
            dtTagID.Columns.Add("RSSI");
            dtTagID.Columns.Add("ReadTime");
#endif

            DataColumn[] columns = new DataColumn[2];
            columns[0] = dtTagID.Columns["TagID"];
            dtTagID.PrimaryKey = columns;
            dtTagID.DefaultView.Sort = "TagID ASC";

            dtViewBuffer = dtTagID.Copy();

            dataGridView1.DataSource = dtViewBuffer.DefaultView;


            DataGridTableStyle dgts = new DataGridTableStyle();

            dgts.MappingName = dtTagID.TableName;

            tbTag.Text = TagCount.ToString();
            dtViewBuffer.DefaultView.Sort = "TagID ASC"; ;
        }
#region Top
        private void comboBox1_Click(object sender, EventArgs e)
        {
            LoadValues();
        }
        private void LoadValues()
        {
            string[] portList = SerialPort.GetPortNames();
            comboBox_comport.Items.Clear();
            comboBox_comport.Items.AddRange(portList);
        }
    
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (rbCom.Checked)
            {
                comboBox_comport.Enabled = true;
            }
        }
#endregion        

#region UI_Control
        private void btnChange(Color foreColor, Color backColor, string msg)
        {
            btnStart.Text = msg;
        }
        private void lbChange( string msg ,bool b)
        {
            label6.Text = msg;
            label6.Visible = b;
        }
        private void tbChange(string msg, int i)
        {
            if (i == 1)
            {
                tbGain.Text = msg;
            }
            else if (i == 2)
            {
                tbTag.Text = msg;
            }
            else if(i == 3)
                tbAtag.Text = msg;
        }
#endregion
        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                if (runThread != null && runThread.IsAlive.Equals(true))
                    runThread.Abort();
            }
            catch (Exception ex)
            { }
            finally
            {
                runThread = new Thread(new ThreadStart(run));
                runThread.IsBackground = true;
                runThread.Start();
            }
        }
        private void run()
        {
            int result=0;
            try
            {
                while (true)
                {
                    if (btnStart.Text == "Start Read Tag")
                    {
                        // this.Invoke(new Action<bool>(rbChange), new object[] { false });
                        this.Invoke(new Action<Color, Color, string>(btnChange), new object[] { Color.DarkOrange, Color.Cyan, "Stop Read Tag" });
                        // this.Invoke(new Action<Color, Color, string, int>(lbChange), new object[] { Color.White, Color.Blue, "Loading", 1 });
                        update = true;
                        result = TT.StartTagInventory();
                    }
                    else if (btnStart.Text == "Stop Read Tag")
                    {
                        update = false;
                        // this.Invoke(new Action<bool>(rbChange), new object[] { true });
                        this.Invoke(new Action<Color, Color, string>(btnChange), new object[] { Color.Red, Color.DarkGray, "Start Read Tag" });
                        //this.Invoke(new Action<Color, Color, string, int>(lbChange), new object[] { Color.White, Color.White, "", 5 });
                        result = TT.StopTagInventory();
                    }
                    if (result == 0)
                        break;
                }
            }
            catch (Exception ex)
            {
            }
        }
        void reader_BulkReadReturn(object sender, HKRFID.Active.HKRAREM.TagReturnEventArgs e)
        {
            try
            {
                this.BeginInvoke(new Action<HKRFID.Active.HKRAREM.TagReturnEventArgs>(this.updateDataGrid), new object[] { e });
            }
            catch
            {
            }
        }
        private void updateDataGrid(HKRFID.Active.HKRAREM.TagReturnEventArgs e)
        {
            if (update)
            {
                string tag_id = HKRFID.Utility.HexTools.ByteArrayToHexString(e.return_tag.tag_id);
                UpdateTime = DateTime.Now;
                AccTagCount++;

                try
                {
                    string tagID = tag_id.Replace("-", "");
                    string sTagID = tagID.Trim().Substring(0, tagID.Length - 2);
                    double sData = 0;

                    lock (dtTagID)
                    {
                        if (((e.return_tag.status.signal_strength == 1) ? "High" : "Low") == comboBox3.Text || comboBox3.Text == "All")
                            if (((e.return_tag.status.battery_status == 1) ? "Normal" : "Low") == comboBox4.Text || comboBox4.Text == "All")
                                if (dtTagID.Rows.Contains(tag_id))
                                {
                                    DataRow dr = dtTagID.Rows.Find(tag_id);
                                    int count = Int32.Parse(dr["Count"].ToString());
                                    count++;
                                    //TagCount++;

                                    dr["Count"] = count.ToString();
                                    dr["Type"] = e.return_tag.status.tag_type.ToString();
                                    dr["Signal_Strength"] = (e.return_tag.status.signal_strength == 1) ? "High" : "Low";
                                    dr["Battery_Status"] = (e.return_tag.status.battery_status == 1) ? "Normal" : "Low";
                                    dr["Last_Updated"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                    // tagTemp.FindIndex();

#if(EM02)
                                    dr["RSSI"] = (e.return_tag.status.rssi*(-1)).ToString();
                                    dr["ReadTime"] = e.return_tag.status.read_time.ToString("yyyy-MM-dd HH:mm:ss");
#endif
                                }
                                else
                                {
                                    TagCount++;
                                    string signal_strength = (e.return_tag.status.signal_strength == 1) ? "High" : "Low";
                                    string battery_status = (e.return_tag.status.battery_status == 1) ? "Normal" : "Low";
                                    dtTagID.Rows.Add(tag_id, "1", e.return_tag.status.tag_type.ToString(), signal_strength, battery_status, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
#if(EM02)
                                    //Ronald Edit: lazy update here, didnt modify the constructor
                                    DataRow dr = dtTagID.Rows.Find(tag_id);
                                    dr["RSSI"] = (e.return_tag.status.rssi * (-1)).ToString();
                                    dr["ReadTime"] = e.return_tag.status.read_time.ToString("yyyy-MM-dd HH:mm:ss");
#endif
                                }
                    }
                }
                catch { }
            }
        }



        private void btnClear_Click(object sender, EventArgs e)
        {
            UpdateTime = DateTime.Now;
            CompareTime = DateTime.Now.AddSeconds(-1);
            dtTagID.Clear();
            dtViewBuffer.Clear();
            TagCount = 0;
            AccTagCount = 0;
        }

        private void btnConn_Click(object sender, EventArgs e)
        {
            btnConn.Text = "Connecting...";
            btnConn.Refresh();

            try
            {
                if (TT != null && TT.isConnected)
                {
                    btnStart.Enabled = false;
                    if (btnStart.Text.Equals("Stop"))
                    {
                        update = false;
                        TT.StopTagInventory();
                    }
                    timerHealth.Stop();
                    TT.Disconnect();
                                         comboBox_comport.Enabled = true;
                    rbCom.Enabled = true;
                    tableLayoutPanel3.Enabled = false ;
                    btnConn.Text = "Connect Reader";
                    btnConn.BackColor = Color.LightSkyBlue;
                }
                else if (TT == null || !TT.isConnected)
                {
                    if (rbCom.Checked)
                    {
                        TT = new HKRFID.Active.HKRAREM(comboBox_comport.SelectedItem.ToString(), HKRFID.Active.HKRAREM.ConnectionType.SerialPort);
                    }
                    else
                    {
                        TT = new HKRFID.Active.HKRAREM(tbHostName.Text, HKRFID.Active.HKRAREM.ConnectionType.TCP);
                    }
                    TT.GetLibVersion();
                    libraryVerToolStripMenuItem.Text += "Library Ver. " + TT.GetLibVersion();
                    TT.Connect();
                    comboBox_comport.Enabled = false;
                    rbCom.Enabled = false;
                    btnConn.Text = "Disconnect Reader";
                    timerHealth.Start();
                    TT.StopTagInventory();
                    tableLayoutPanel3.Enabled = true;
                    //btnConn.BackColor = Color.Gray;
                    // Register receive tags event, reader_BulkReadReturn
                    TT.TagReturn += new EventHandler<HKRFID.Active.HKRAREM.TagReturnEventArgs>(reader_BulkReadReturn);
#if(EM02)
                    TT.NumOfTagReturn += new EventHandler<HKRFID.Active.HKRAREM.NumOfTagReturnEventArgs>(TT_NumOfTagReturn);
#endif

                    btnStart.Enabled = true;
                }
            }
            catch
            {
                btnConn.Text = "Fail to Connect";
                System.Windows.Forms.MessageBox.Show("Connection Problem");
                btnConn.Text = "Connect Reader";
            }
        }
#if(EM02)
        void TT_NumOfTagReturn(object sender, HKRFID.Active.HKRAREM.NumOfTagReturnEventArgs e)
        {
            int returningNumOfTag = e.num_tag_returning;
            this.Invoke(new Action<int>(upateNumOfTagReturn), new object[] { returningNumOfTag });
        }
        
        private void upateNumOfTagReturn(int numOfTagReturning)
        {
            lbReturnNum.Text = "Returning: " + numOfTagReturning + "(Tags)";
        }

#endif
        private void timerHealth_Tick(object sender, EventArgs e)
        {
            try
            {
                if (UpdateTime.CompareTo(CompareTime) <= 0)
                {
                    if (!TT.isConnected) 
                    {
                        Console.WriteLine("disconnect");
                        TT.Connect();
                        if (TT.isConnected) Console.WriteLine("connect");
                        TT.TagReturn += new EventHandler<HKRFID.Active.HKRAREM.TagReturnEventArgs>(reader_BulkReadReturn);
                        if (btnStart.Text.Equals("Stop"))
                            TT.StartTagInventory();
                    }
                }
                else
                {
                    CompareTime = UpdateTime;
                }
            }
            catch { }
        }

        private void timerUI_Tick(object sender, EventArgs e)
        {
            if (update)
            {
                int dg1i = dataGridView1.FirstDisplayedScrollingRowIndex;
                DataTable dtFilter = Filtering(dtTagID);
                dtViewBuffer.Merge(dtFilter, false);
                try
                {
                    dataGridView1.FirstDisplayedScrollingRowIndex = dg1i;
                }
                catch { }
            }
            this.Invoke(new Action<string, int>(tbChange), new object[] { TagCount.ToString(), 2 });
            this.Invoke(new Action<string, int>(tbChange), new object[] { AccTagCount.ToString(), 3 });
            //
            if (cbAutoGetStatus.Checked)
            {
                btnGetReaderStatus_Click(this, null);
            }
        }
        private DataTable Filtering(DataTable dt)
        {
            DataTable dtf = dt;
            try
            { 
                
            }
            catch { }
            return dtf;
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (TT != null && TT.isConnected)
            {
                btnStart.Enabled = false;
                if (btnStart.Text.Equals("Stop"))
                {
                    update = false;
                    btnChange(Color.Red, Color.DarkGray, "Start");
                    TT.StopTagInventory();
                }
                TT.Disconnect();
               
                    comboBox_comport.Enabled = true;
                rbCom.Enabled = true;

                btnConn.Text = "Connect";
            }
        }

   

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnClear_Click(sender, e);
        }

        private void btnGetGain_Click(object sender, EventArgs e)
        {
            int result;
            try
            {
                result = TT.GetGain();
                if (result >= 0)
                {
                    int gain = result;
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                    this.Invoke(new Action<string, int>(tbChange), new object[] { result.ToString(), 1 });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                    this.Invoke(new Action<string, int>(tbChange), new object[] { "", 1 });
                }
                Application.DoEvents();
            }
            catch (Exception ex)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                Application.DoEvents();
            }
            finally
            {
                Thread.Sleep(1000);
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
            }
        }

        private void btnSetGain_Click(object sender, EventArgs e)
        {
            int result;
            try
            {
                int gainVal = Convert.ToInt32(tbGain.Text);
                if (gainVal < 0)
                    throw new Exception();
                result = TT.SetGain(gainVal);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception ex)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                Application.DoEvents();
            }
            finally
            {
                Thread.Sleep(1000);
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            selectTCPConnection();

            //program ver.
            Assembly assembly = Assembly.GetExecutingAssembly();
            FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
            string version = fvi.ProductVersion;

            demoProgramVerToolStripMenuItem.Text += " " + version;            
        }

        private void selectSerialConnection()
        {
            //visible serial component
            serialToolStripMenuItem.Checked = true;
            comboBox_comport.Visible = true;
            rbCom.Visible = true;
            rbCom.Checked = true;

            //invisible tcp component
            tCPToolStripMenuItem.Checked = false;
            tbHostName.Visible = false;
            rbTcp.Visible = false;
            rbTcp.Checked = false;
        }

        private void selectTCPConnection()
        {
            //invisible serial component
            serialToolStripMenuItem.Checked = false;
            comboBox_comport.Visible = false;
            rbCom.Visible = false;
            rbCom.Checked = false;

            //invisible tcp component
            tCPToolStripMenuItem.Checked = true;
            tbHostName.Visible = true;
            rbTcp.Visible = true;
            rbTcp.Checked = true;
        }

        private void btnReaderLED_Click(object sender, EventArgs e)
        {
            int result;
            try
            {
                result = TT.SetReaderLEDOn();
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception ex)
            {
            }
            finally
            {
                Thread.Sleep(1000);
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
            }
        }

        private void btnReaderBuzzer_Click(object sender, EventArgs e)
        {
            int result;
            try
            {

                result = TT.SetReaderBuzzerOn();
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception ex)
            {
            }
            finally
            {
                Thread.Sleep(1000);
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
            }
        }

        private void btnLEDBuzzer_Click(object sender, EventArgs e)
        {
            int result;
            try
            {                
                result = TT.SetReaderBuzzerAndLEDOn();
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception ex)
            {
            }
            finally
            {
                Thread.Sleep(1000);
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnGetReaderStatus_Click(object sender, EventArgs e)
        {
            try
            {
                var result = TT.GetReaderStatus();                
                tbEM02Result.Text = result.ToString();
            }
            catch (Exception ex)
            {
                //disable auto get anyway
                cbAutoGetStatus.Checked = false;
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnGetSecuredSN_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] outputSerial = new byte[8];
                var result = TT.GetSerialNumber_Secured(ref outputSerial);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
                tbEM02Result.Text = HKRFID.Utility.HexTools.ByteArrayToHexString(outputSerial);
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnGetSn_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] outputSerial = new byte[8];
                var result = TT.GetSerialNumber(ref outputSerial);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
                tbEM02Result.Text = HKRFID.Utility.HexTools.ByteArrayToHexString(outputSerial);
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void cbSystemTime_CheckedChanged(object sender, EventArgs e)
        {
            tbReaderTime.Enabled = !((CheckBox)sender).Checked;
        }

        private void btnSetReaderTime_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbSystemTime.Checked)
                {
                    tbReaderTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }
                else
                {
                    //check for datatime input
                }
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetReaderTime(DateTime.ParseExact(tbReaderTime.Text, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnSetHB_Click(object sender, EventArgs e)
        {
            try
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetHeartbeat(cbHeartBeat.Checked);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnResetReader_Click(object sender, EventArgs e)
        {
            try
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.ResetReader();
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnGPIODir_Click(object sender, EventArgs e)
        {
            try
            {
                int mask = 0;
                int value = 0;

                if (setDirMask1.Checked) { mask |= 0x01; }
                if (setDirMask2.Checked) { mask |= 0x02; }
                if (setDirMask3.Checked) { mask |= 0x04; }
                if (setDir1.Checked) { value |= 0x01; }
                if (setDir2.Checked) { value |= 0x02; }
                if (setDir3.Checked) { value |= 0x04; }

                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetGPIODirection(mask, value);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();

            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnSetGPIOVal_Click(object sender, EventArgs e)
        {
            try
            {
                int mask = 0;
                int value = 0;
                if (setValMask1.Checked) { mask |= 0x01; }
                if (setValMask2.Checked) { mask |= 0x02; }
                if (setValMask3.Checked) { mask |= 0x04; }
                if (setVal1.Checked) { value |= 0x01; }
                if (setVal2.Checked) { value |= 0x02; }
                if (setVal3.Checked) { value |= 0x04; }

                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetGPIOValue(mask, value);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnSetReaderMode_Click(object sender, EventArgs e)
        {
            try
            {
                HKRFID.Active.HKRAREM.ReaderMode mode = HKRFID.Active.HKRAREM.ReaderMode.Classic;
                if (cbReaderMode.SelectedIndex == 1)
                {
                    mode = HKRFID.Active.HKRAREM.ReaderMode.Classic;
                }
                else if (cbReaderMode.SelectedIndex == 0)
                {
                    mode = HKRFID.Active.HKRAREM.ReaderMode.EM02Mode;
                }
                else
                {
                    throw new Exception("Please select");
                }

                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetReaderMode(mode);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });                
            }
        }

        private void btnSetReqMode_Click(object sender, EventArgs e)
        {
            try
            {
                HKRFID.Active.HKRAREM.RequestMode mode = HKRFID.Active.HKRAREM.RequestMode.Active;
                if (cbRequestMode.SelectedIndex == 0)
                {
                    mode = HKRFID.Active.HKRAREM.RequestMode.Active;
                }
                else if (cbRequestMode.SelectedIndex == 1)
                {
                    mode = HKRFID.Active.HKRAREM.RequestMode.Passive;
                }
                else
                {
                    throw new Exception("Please select");
                }

                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetRequestMode(mode);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });                
            }
        }

        private void btnGetTagBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.GetTagBuffer();
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnGetNClaer_Click(object sender, EventArgs e)
        {
            try
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.GetTagBufferAndClear();
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnClearBuffer_Click(object sender, EventArgs e)
        {
            try
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.ClearTagBuffer();
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void serialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            selectSerialConnection();
        }

        private void tCPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            selectTCPConnection();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void btnSetReaderFrequency_Click(object sender, EventArgs e)
        {
            try
            {
                HKRFID.Active.HKRAREM.ReaderFrequency mode = HKRFID.Active.HKRAREM.ReaderFrequency.US;
                if (cbReaderFrequency.SelectedIndex == 0)
                {
                    mode = HKRFID.Active.HKRAREM.ReaderFrequency.US;
                }
                else if (cbReaderFrequency.SelectedIndex == 1)
                {
                    mode = HKRFID.Active.HKRAREM.ReaderFrequency.EU;
                }
                else
                {
                    throw new Exception("Please select");
                }

                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetReaderFrequency(mode);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnSetReaderChannel_Click(object sender, EventArgs e)
        {
            try
            {
                HKRFID.Active.HKRAREM.ReaderChannel mode = HKRFID.Active.HKRAREM.ReaderChannel.EM;
                if (cbReaderChannel.SelectedIndex == 1)
                {
                    mode = HKRFID.Active.HKRAREM.ReaderChannel.LX;
                }
                else if (cbReaderChannel.SelectedIndex == 0)
                {
                    mode = HKRFID.Active.HKRAREM.ReaderChannel.EM;
                }
                else
                {
                    throw new Exception("Please select");
                }

                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetReaderChannel(mode);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnSetSampleTime_Click(object sender, EventArgs e)
        {
            try
            {
                HKRFID.Active.HKRAREM.ReadInterval mode = HKRFID.Active.HKRAREM.ReadInterval.Short;
                if (cbSampleTime.SelectedIndex == 2)
                {
                    mode = HKRFID.Active.HKRAREM.ReadInterval.Instant;
                }
                else if (cbSampleTime.SelectedIndex == 1)
                {
                    mode = HKRFID.Active.HKRAREM.ReadInterval.Long;
                }else if(cbSampleTime.SelectedIndex == 0)
                {
                    mode = HKRFID.Active.HKRAREM.ReadInterval.Short;
                }
                else
                {
                    throw new Exception("Please select");
                }

                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.SetReadInterval(mode);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnGetNClaer_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
                Application.DoEvents();
                var result = TT.GetTagBufferAndClear();
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void tableLayoutPanel_TagList_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnGetReaderVersion_Click(object sender, EventArgs e)
        {
            try
            {
                string result = TT.GetReaderVersion();
                if (result != "")
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
                tbEM02Result.Text = result;//HKRFID.Utility.HexTools.ByteArrayToHexString(outputSerial);
            }
            catch (Exception)
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
            }
        }

        private void btnReaderBuzzer_Click_1(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
