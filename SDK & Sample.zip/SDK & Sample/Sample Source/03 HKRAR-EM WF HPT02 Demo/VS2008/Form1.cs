﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using ZedGraph;
using System.Diagnostics;

namespace HPT02_Demo
{
    public partial class Form1 : Form
    {

#region global variable
        //To commulicate with Active Reader's object
        private HKRFID.Active.HKRAREM HPT;

        DataTable dtTagID = null,dtViewBuffer = null;
        private Thread runThread;
        private bool update = false;
        private DateTime CompareTime ,UpdateTime;
        //private Int64 AccTagCount, TagCount;
        int AccTagCount, TagCount;
        private string selectedTag;

        private List<DateTime> Xdata = new List<DateTime>();
        private List<double> Ydata = new List<double>();
        private LineItem myCurve;
        private PointPairList list = new PointPairList();
        
        private List<DateTime> XdataH = new List<DateTime>();
        private List<double> YdataH = new List<double>();
        private LineItem myCurveH;
        private PointPairList listH = new PointPairList();
        private System.Resources.ResourceManager rm;

        #endregion

#region initial_Control
        //Initalize the datatable, and the layout of the program
        public Form1()
        {
            InitializeComponent();
            Init();
        }
        private void Init()
        {
            btnConn.BackColor = Color.DarkRed;
            btnConn.ForeColor = Color.Lime;
            btnStart.BackColor = Color.LavenderBlush;
            btnStart.ForeColor = Color.Firebrick;
            tableLayoutPanel3.Enabled = false;
            TagCount = 0;
            AccTagCount = 0;
            //comboBox1.Enabled = false;
            dtTagID = new DataTable();
            dtViewBuffer = new DataTable();
            CompareTime = DateTime.Now;
            UpdateTime = DateTime.Now;
            dtTagID.Columns.Add("TagID");
            dtTagID.Columns.Add("Count", typeof(int));
            dtTagID.Columns.Add("Type");
            dtTagID.Columns.Add("Data");
            dtTagID.Columns.Add("Signal_Strength");
            dtTagID.Columns.Add("Battery_Status");
            dtTagID.Columns.Add("Last_Updated");

            DataColumn[] columns = new DataColumn[2];
            columns[0] = dtTagID.Columns["TagID"];
            dtTagID.PrimaryKey = columns;
            dtTagID.DefaultView.Sort = "TagID ASC";

            dtViewBuffer = dtTagID.Copy();

            dataGridView1.DataSource = dtViewBuffer.DefaultView;

            DataGridTableStyle dgts = new DataGridTableStyle();

            dgts.MappingName = dtTagID.TableName;

            dataGridView1.Columns["TagID"].Width = 135;
            dataGridView1.Columns["Count"].Width = 45;
            dataGridView1.Columns["Type"].Width = 90;
            dataGridView1.Columns["Data"].Width = 80;
            dataGridView1.Columns["Signal_strength"].Width = 90;
            dataGridView1.Columns["Battery_Status"].Width = 80;
            dataGridView1.Columns["Last_Updated"].Width = 120;
            tbTag.Text += TagCount.ToString();
            tbAtag.Text += AccTagCount.ToString();

            dtViewBuffer.DefaultView.Sort = "TagID ASC"; 
            zg1.GraphPane.Title.Text = "Temperature Graph";
            zg1.GraphPane.XAxis.Title.Text = "Time";
            zg1.GraphPane.YAxis.Title.Text = "Degree C";
            zg1.GraphPane.XAxis.Type = ZedGraph.AxisType.DateAsOrdinal;
            zg1.GraphPane.XAxis.Scale.MaxAuto = true;
            myCurve = zg1.GraphPane.AddCurve("My Curve", list, Color.DarkGreen, SymbolType.None);

            zg2.GraphPane.Title.Text = "Humidity Graph";
            zg2.GraphPane.XAxis.Title.Text = "Time";
            zg2.GraphPane.YAxis.Title.Text = "%";
            zg2.GraphPane.XAxis.Type = ZedGraph.AxisType.DateAsOrdinal;
            zg2.GraphPane.XAxis.Scale.MaxAuto = true;
            myCurveH = zg2.GraphPane.AddCurve("My Curve", listH, Color.DarkGreen, SymbolType.None);
        }
#endregion

#region Top Panel
        //layout change
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
         
        }
     
#endregion        

#region UI_Control
        //layout change by Invoke
        private void btnChange(Color foreColor, Color backColor, string msg)
        {
            btnStart.ForeColor = foreColor;
            btnStart.BackColor = backColor;
            btnStart.Text = msg;
        }
        private void lbChange( string msg ,bool b)
        {
            label6.Text = msg;
            label6.Visible = b;
        }
        private void tbChange(string msg, int i)
        {
            if (i == 1)
                tbGain.Text = msg;
            else if (i == 2)
                tbTag.Text = msg;
            else if(i == 3)
                tbAtag.Text = msg;
            else if (i == 4)
            {
                tbCurrT.Text = msg;
                tbMaxT.Text = Ydata.Max().ToString();
                tbMinT.Text = Ydata.Min().ToString();
            }
            else if (i == 5)
            {
                tbCurrH.Text = msg;
                tbMaxH.Text = YdataH.Max().ToString();
                tbMinH.Text = YdataH.Min().ToString();
            }
        }
#endregion

#region timer_Control
        //timer for updating the datagridview
        private void timerUI_Tick(object sender, EventArgs e)
        {
            if (update)
            {
                //int dg1i = dataGridView1.FirstDisplayedScrollingRowIndex;
                DataTable dtFilter = dtTagID;
                dtViewBuffer.Merge(dtFilter, false);
                try
                {
                    //dataGridView1.FirstDisplayedScrollingRowIndex = dg1i;
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                        if (dataGridView1.Rows[i].Cells[0].Value.ToString().Replace("-", "").Replace(" ", "") == selectedTag)
                        {
                            int dg1i = i;// dataGridView1.FirstDisplayedScrollingRowIndex;
                            dataGridView1.FirstDisplayedScrollingRowIndex = dg1i;
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
                }
                catch { }
            this.Invoke(new Action<string, int>(tbChange), new object[] { TagCount.ToString(), 2 });
            this.Invoke(new Action<string, int>(tbChange), new object[] { AccTagCount.ToString(), 3 });
            }
            
        }
        #endregion

#region runtime_Control

        //Call Command to Connect and Disconnect the Reader
        private void btnConn_Click(object sender, EventArgs e)
        {
            try
            {
                if (HPT != null && HPT.isConnected)
                {
                    btnStart.Enabled = false;
                    if (btnStart.Text.Equals("Stop"))
                    {
                        update = false;
                        this.Invoke(new Action<Color, Color, string>(btnChange), new object[] { Color.Firebrick, Color.LavenderBlush, "Start" });
                        HPT.StopTagInventory();
                    }
                    HPT.Disconnect();
                        textBox1.Enabled = true;
                    radioButton1.Enabled = true;
                    tableLayoutPanel3.Enabled = false;
                    btnConn.Text = "Connect";
                    btnConn.BackColor = Color.DarkRed;
                    btnConn.ForeColor = Color.Lime;
                }
                else if (HPT == null || !HPT.isConnected)
                {
                    HPT = new HKRFID.Active.HKRAREM(textBox1.Text, HKRFID.Active.HKRAREM.ConnectionType.TCP);

                    HPT.GetLibVersion();
                    //HPT.Connect();
                    HPT.AsynConnect();
                    Thread.Sleep(500);
                    //ADD
                    TagCount = 0;
                    AccTagCount = 0;                    
                    HPT.StopTagInventory();
                    textBox1.Enabled = false;
                    radioButton1.Enabled = false;
                    btnConn.Text = "Disconnect";
                    HPT.SetReaderChannel(HKRFID.Active.HKRAREM.ReaderChannel.EM);
                    HPT.SetReadInterval(HKRFID.Active.HKRAREM.ReadInterval.Short);
                    tableLayoutPanel3.Enabled = true;
                    btnConn.BackColor = Color.Silver;
                    btnConn.ForeColor = Color.Red;
                    HPT.TagReturn += new EventHandler<HKRFID.Active.HKRAREM.TagReturnEventArgs>(reader_BulkReadReturn);

                    btnStart.Enabled = true;
                }
            }
            catch(Exception ex)
            { }
        }

        //Call a Thread to Read Tag
        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                if (runThread != null && runThread.IsAlive.Equals(true))
                    runThread.Abort();
            }
            catch
            { }
            finally
            {
                runThread = new Thread(new ThreadStart(run));
                runThread.IsBackground = true;
                runThread.Start();
            }
        }
        //A running thread for StartTagInventory and StopTagInventory
        private void run()
        {
            int result = 1;
            try
            {
                while (true)
                {
                    if (btnStart.Text == "Start")
                    {
                        this.Invoke(new Action<Color, Color, string>(btnChange), new object[] { Color.Red, Color.Silver, "Stop" });
                        update = true;
                        result = HPT.StartTagInventory();
                    }
                    else if (btnStart.Text == "Stop")
                    {
                        update = false;
                        this.Invoke(new Action<Color, Color, string>(btnChange), new object[] { Color.Firebrick, Color.LavenderBlush, "Start" });
                        result = HPT.StopTagInventory();
                    }
                    if (result == 0)
                        break;
                }
            }
            catch
            {
            }
        }

        //Clear the Datagridview
        private void btnClear_Click(object sender, EventArgs e)
        {
            UpdateTime = DateTime.Now;
            CompareTime = DateTime.Now.AddSeconds(-1);
            dtTagID.Clear();
            dtViewBuffer.Clear();
            TagCount = 0;
            AccTagCount = 0;
        }
        //Clear the graphT
        private void btnClearG_Click(object sender, EventArgs e)
        {
            tbCurrT.Text = "";
            tbMaxT.Text = "";
            tbMinT.Text = "";
            Xdata.Clear();
            Ydata.Clear();
            list.Clear();
        }
        //Clear the graphH
        private void btnClearH_Click(object sender, EventArgs e)
        {
            tbCurrH.Text = "";
            tbMaxH.Text = "";
            tbMinH.Text = "";
            XdataH.Clear();
            YdataH.Clear();
            listH.Clear();
        }
        //Call Command to Get Gain of reader
        private void btnGetGain_Click(object sender, EventArgs e)
        {
            int result;
            try
            {
                result = HPT.GetGain();
                if (result >= 0)
                {
                    int gain = result;
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                    this.Invoke(new Action<string, int>(tbChange), new object[] { result.ToString(), 1 });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                    this.Invoke(new Action<string, int>(tbChange), new object[] { "", 1 });
                }
                Application.DoEvents();
            }
            catch
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                Application.DoEvents();
            }
            finally
            {
                Thread.Sleep(1000);
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
            }
        }
        //Call Command to Set Gain of reader
        private void btnSetGain_Click(object sender, EventArgs e)
        {
            int result;
            try
            {
                int gainVal = Convert.ToInt32(tbGain.Text);
                if (gainVal < 0 || gainVal > 31)
                    throw new Exception();
                result = HPT.SetGain(gainVal);
                if (result == 0)
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "OK", true });
                }
                else
                {
                    this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                }
                Application.DoEvents();
            }
            catch
            {
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "FAIL", true });
                Application.DoEvents();
            }
            finally
            {
                Thread.Sleep(1000);
                this.Invoke(new Action<string, bool>(lbChange), new object[] { "", false });
            }
        }
        //Datatable row seleted
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows[0].Cells[0].Value.ToString().Replace("-", "").Replace(" ", "") == null) return;
                if (selectedTag != dataGridView1.SelectedRows[0].Cells[0].Value.ToString().Replace("-", "").Replace(" ", ""))
                {
                    try
                    {
                        selectedTag = dataGridView1.SelectedRows[0].Cells[0].Value.ToString().Replace("-", "").Replace(" ", "");
                        zg1.GraphPane.CurveList[0].Label.Text = selectedTag;
                        zg2.GraphPane.CurveList[0].Label.Text = selectedTag;
                        btnClearG_Click(sender, e);
                        btnClearH_Click(sender, e);
                    }
                    catch { selectedTag = null; }
                }
            }
            catch { selectedTag = null; }
        }
#endregion

#region Process the return tag
        //A event handler for the reader read tag return 
        void reader_BulkReadReturn(object sender, HKRFID.Active.HKRAREM.TagReturnEventArgs e)
        {
            try
            {
                this.BeginInvoke(new Action<HKRFID.Active.HKRAREM.TagReturnEventArgs>(this.updateDataGrid), new object[] { e });
            }
            catch
            {
            }
        }
        private void updateDataGrid(HKRFID.Active.HKRAREM.TagReturnEventArgs e)
        {
            if (update)
            {
                string tag_id = HKRFID.Utility.HexTools.ByteArrayToHexString(e.return_tag.tag_id);
                UpdateTime = DateTime.Now;

                try
                {
                    string tagID = tag_id.Replace("-", "");
                    lock (dtTagID)
                    {
                        if (((e.return_tag.status.signal_strength == 1) ? "High" : "Low") == comboBox3.Text || comboBox3.Text == "All")
                            if (((e.return_tag.status.battery_status == 1) ? "Normal" : "Low") == comboBox4.Text || comboBox4.Text == "All")
                            {
                                if (dtTagID.Rows.Contains(tag_id))
                                {
                                    DataRow dr = dtTagID.Rows.Find(tag_id);
                                    int count = Int32.Parse(dr["Count"].ToString());
                                    count++;
                                    AccTagCount++;

                                    dr["Count"] = count.ToString();
                                    dr["Type"] = e.return_tag.status.tag_type.ToString().Replace("_", "-");
                                    dr["Signal_Strength"] = (e.return_tag.status.signal_strength == 1) ? "High" : "Low";
                                    dr["Battery_Status"] = (e.return_tag.status.battery_status == 1) ? "Normal" : "Low";
                                    dr["Last_Updated"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                    if (e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.Internal)
                                    {
                                        Console.WriteLine("");
                                    }
                                    if (e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.HKRAT_TT02 || e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.HKRAT_TT02X)
                                    {
                                        try
                                        {
                                            double temp = HPT.CalucalateTemperature(e.return_tag.status.sensor_data);
                                            dr["Data"] = temp.ToString() + " (C)";
                                            if (selectedTag == tagID)
                                            {
                                                list.Add((double)new XDate(DateTime.Now), temp);
                                                Ydata.Add(temp);
                                                GraphUpdate();
                                                this.Invoke(new Action<string, int>(tbChange), new object[] { temp.ToString(), 4 });
                                            }
                                        }
                                        catch
                                        {
                                            dr["Data"] = "Err";
                                        }
                                    }
                                    else if (e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.HKRAT_PT02)
                                    {
                                        try
                                        {
                                            double temp = HPT.CalucalateTemperature_PT(e.return_tag.status.sensor_data);
                                            dr["Data"] = temp.ToString() + " (C)";
                                            if (selectedTag == tagID)
                                            {
                                                list.Add((double)new XDate(DateTime.Now), temp);
                                                Ydata.Add(temp);
                                                GraphUpdate();
                                                this.Invoke(new Action<string, int>(tbChange), new object[] { temp.ToString(), 4 });
                                            }
                                        }
                                        catch
                                        {
                                            dr["Data"] = "Err";
                                        }
                                    }
                                    else if (e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.HKRAT_HT02)
                                    {
                                        try
                                        {
                                            double temp = HPT.CalucalateTemperature_HT(e.return_tag.status.sensor_data);
                                            double humidity = HPT.CalucalateHumidity_HT(e.return_tag.status.sensor_data);
                                            dr["Data"] = temp.ToString() + " (C)," + humidity.ToString() + "%";

                                            if (selectedTag == tagID)
                                            {
                                                list.Add((double)new XDate(DateTime.Now), temp);
                                                Ydata.Add(temp);
                                                listH.Add((double)new XDate(DateTime.Now), humidity);
                                                YdataH.Add(humidity);
                                                this.Invoke(new Action<string, int>(tbChange), new object[] { temp.ToString(), 4 });
                                                this.Invoke(new Action<string, int>(tbChange), new object[] { humidity.ToString(), 5 });
                                                GraphUpdate();
                                            }
                                        }
                                        catch
                                        {
                                            dr["Data"] = "Err";
                                        }
                                    }
                                }
                                else
                                {
                                    AccTagCount++;
                                    TagCount++;
                                    string signal_strength = (e.return_tag.status.signal_strength == 1) ? "High" : "Low";
                                    string battery_status = (e.return_tag.status.battery_status == 1) ? "Normal" : "Low";
                                    string data = "";
                                    if (e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.HKRAT_TT02 || e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.HKRAT_TT02X)
                                    {
                                        try
                                        {
                                            double temp = HPT.CalucalateTemperature(e.return_tag.status.sensor_data);
                                            data = temp.ToString() + " (C)";
                                            if (selectedTag == tagID)
                                            {
                                                list.Add((double)new XDate(DateTime.Now), temp);
                                                Ydata.Add(temp);
                                                GraphUpdate();
                                                this.Invoke(new Action<string, int>(tbChange), new object[] { temp.ToString(), 4 });
                                            }
                                        }
                                        catch
                                        {
                                            data = "Err";
                                        }
                                    }
                                    else if (e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.HKRAT_PT02)
                                    {
                                        try
                                        {
                                            double temp = HPT.CalucalateTemperature_PT(e.return_tag.status.sensor_data);
                                            data = temp.ToString() + " (C)";
                                            if (selectedTag == tagID)
                                            {
                                                list.Add((double)new XDate(DateTime.Now), temp);
                                                Ydata.Add(temp);
                                                GraphUpdate();
                                                this.Invoke(new Action<string, int>(tbChange), new object[] { temp.ToString(), 4 });
                                            }
                                        }
                                        catch
                                        {
                                            data = "Err";
                                        }
                                    }
                                    else if (e.return_tag.status.tag_type == HKRFID.Active.HKRAREM.TagType.HKRAT_HT02)
                                    {
                                        try
                                        {
                                            double temp = HPT.CalucalateTemperature_HT(e.return_tag.status.sensor_data);
                                            double humidity = HPT.CalucalateHumidity_HT(e.return_tag.status.sensor_data);
                                            data = temp.ToString() + " (C)," + humidity.ToString() + "%";

                                            if (selectedTag == tagID)
                                            {
                                                list.Add((double)new XDate(DateTime.Now), temp);
                                                Ydata.Add(temp);
                                                listH.Add((double)new XDate(DateTime.Now), humidity);
                                                YdataH.Add(humidity);
                                                this.Invoke(new Action<string, int>(tbChange), new object[] { temp.ToString(), 4 });
                                                this.Invoke(new Action<string, int>(tbChange), new object[] { humidity.ToString(), 5 });
                                                GraphUpdate();
                                            }
                                        }
                                        catch
                                        {
                                            data = "Err";
                                        }
                                    }
                                    dtTagID.Rows.Add(tag_id, "1", e.return_tag.status.tag_type.ToString().Replace("_", "-"), data, signal_strength, battery_status, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                                }
                            }
                    }
                }
                catch { }
            }
        }
        //Update Graph
        public void GraphUpdate()
        {
            this.zg1.AxisChange();
            this.zg1.Refresh();
            this.zg2.AxisChange();
            this.zg2.Refresh();
        }
#endregion

        //Disconnect and Stop ReadTag if the reader is working when the program close
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (HPT != null && HPT.isConnected)
            {
                btnStart.Enabled = false;
                if (btnStart.Text.Equals("Stop"))
                {
                    update = false;
                    btnChange(Color.Red, Color.DarkGray, "Start");
                    HPT.StopTagInventory();
                }
                HPT.Disconnect();
                    textBox1.Enabled = true;
                radioButton1.Enabled = true;

                btnConn.Text = "Connect";
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(    "Company:  " + "Hong Kong RFID Limit\r\n" +
                                "Software: " + "The Demo Program of Temperature and Humidity Tag\r\n" +
                                "Reader Support:  " + "HKRAR-EMWF,HKRAR-EMPOE\r\n" +
                                "Tag Support:  " + "RT02, NT02, TT02, TT02x, HT02, PT02\r\n" +
                                "Version:  " + "1.5.3.0\r\n" +
                                "Remark:   " + "The Graph is using ZedGraph.dll (zedgraph.sourceforge.net)\r\n" +
                                "", "About");
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                selectedTag = dataGridView1.SelectedRows[0].Cells[0].Value.ToString().Replace("-", "").Replace(" ", "");
            }
            catch { }

        }


    }
}
