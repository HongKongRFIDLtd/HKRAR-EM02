﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Demo
{
    #region Public Delegates

    // delegates used to call MainForm functions from worker thread
    public delegate void DelegateAddMsg(int boxid, String s);

    #endregion

    public partial class Form1 : Form
    {
        HKRAR_EM iHKRAR_EM = null;
        private Thread m_ListenerThread = null;

        public DelegateAddMsg m_DelegateAddMsg;


        private DataTable m_TagDataTable = new DataTable("Tag List");

        public Form1()
        {
            InitializeComponent();
            this.m_TagDataTable.Columns.Add("TagID");
            this.m_TagDataTable.Columns.Add("Signal");
            this.m_TagDataTable.Columns.Add("Battery");
            this.dataGridView1.DataSource = m_TagDataTable;

            DataGridTableStyle dgts = new DataGridTableStyle();
            dgts.MappingName = "Tag List";
            dgts.ReadOnly = true;
            dgts.RowHeadersVisible = false;

            DataGridColumnStyle dgcsTagID = new DataGridTextBoxColumn();
            dgcsTagID.MappingName = "TagID";
            dgcsTagID.HeaderText = "TagID";
            dgcsTagID.Width = 200;

            DataGridColumnStyle dgcsStatus = new DataGridTextBoxColumn();
            dgcsStatus.MappingName = "Signal";
            dgcsStatus.Width = 200;
            dgcsStatus.HeaderText = "Signal";

            DataGridColumnStyle dgcsStatus2 = new DataGridTextBoxColumn();
            dgcsStatus2.MappingName = "Battery";
            dgcsStatus2.Width = 100;
            dgcsStatus2.HeaderText = "Battery";

            dgts.GridColumnStyles.Add(dgcsTagID);
            dgts.GridColumnStyles.Add(dgcsStatus);
            dgts.GridColumnStyles.Add(dgcsStatus2);

            this.dataGridView1.TableStyles.Clear();
            this.dataGridView1.TableStyles.Add(dgts);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        public void setStatus(string s)
        {
            lblStatus.Text = s;
        }

        public void setReading(bool b)
        {
            btnStartRead.Enabled = !b;
            btnStopRead.Enabled = b;

        }

        public void setConnected(bool b)
        {
            btnConnect.Enabled = !b;
            btnDisconnect.Enabled = b;
            button1.Enabled = b;
            button2.Enabled = b;
            button3.Enabled = b;
        }

        public void addTagRecord(string TagID, int TagStatus)
        {
            string filter = string.Format("TagID='{0}'", TagID.Trim());
            DataRow[] drs = m_TagDataTable.Select(filter);
            string status_msg, status_msg2;
            if (((TagStatus >> 5) & 0x01) == 0x01)
            {
                status_msg = "High";
            }
            else
            {
                status_msg = "Low";
            }
            if ((TagStatus & 0x01) == 0x01)
            {
                status_msg2 = "OK";
            }
            else
            {
                status_msg2 = "Low";
            }
            if (drs != null && drs.Length > 0)
            {

                int tpower = ((TagStatus & 0x18) >> 3);
                int tinterval = ((TagStatus & 0x06) >> 1);

                int tstatus = (TagStatus);

                drs[0]["Signal"] = status_msg;
                drs[0]["Battery"] = status_msg2;
            }
            else
            {
                DataRow dr = m_TagDataTable.NewRow();
                dr["TagID"] = TagID.Trim();

                dr["Signal"] = status_msg;
                dr["Battery"] = status_msg2;

                m_TagDataTable.Rows.Add(dr);
            }


            dataGridView1.ResumeLayout();
            Application.DoEvents();


        }

		private void ListenerThreadProc()
        {
            //*********************************************
            //***  Thread for getting reader data       ***
            //*********************************************
            try
            {
            iHKRAR_EM = new HKRAR_EM( this,
                                          this.txtIP.Text, Int32.Parse(txtPort.Text));
                if (iHKRAR_EM != null)
                {
                    iHKRAR_EM.Run(); // ** functions for parse incoming data from reader
                }
            }
            catch 
            {
                return;
            }
            
		}

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (m_ListenerThread != null && m_ListenerThread.IsAlive)
            {
                MessageBox.Show("Please disconnect first");
                return;
            }
            m_ListenerThread = new Thread(new ThreadStart(ListenerThreadProc));
            m_ListenerThread.IsBackground = true;
            m_ListenerThread.Start();
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (iHKRAR_EM != null && btnStopRead.Visible)
            {
                iHKRAR_EM.StopRead();
                setReading(false);
            } 
            m_ListenerThread.Abort();
//			m_EventStopThread.Set();
			if (iHKRAR_EM != null)
			{
				iHKRAR_EM.ClosePort();
                iHKRAR_EM = null;
            }
        }

        private void btnReadTag_Click(object sender, EventArgs e)
        {
            if (iHKRAR_EM != null)
            {
                iHKRAR_EM.StartRead();
            } 

        }

        private void btnStopRead_Click(object sender, EventArgs e)
        {
            if (iHKRAR_EM != null)
            {
                iHKRAR_EM.StopRead();
            }  
        }

        private void button1_Click(object sender, EventArgs e)
        {
            iHKRAR_EM.getReaderVersion();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            m_DelegateAddMsg = new DelegateAddMsg(this.AddMsg);
            setReading(false); // update screen appearance
            setConnected(false);// update screen appearance
        }



        private void AddMsg(int boxid, string s)
        {
            if (boxid == 1)
            {
                if (this.listBox1.Items.Count > 5000) this.listBox1.Items.Clear();

                this.listBox1.Items.Add(s.Trim());
                this.listBox1.TopIndex = this.listBox1.Items.Count - 1;
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            iHKRAR_EM.GetGain();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte sG = (byte)(Convert.ToInt16( textBox1.Text,10) );
            iHKRAR_EM.SetGain(sG);
        }


    }
}
