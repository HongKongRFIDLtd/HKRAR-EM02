using System;
using System.Threading;
using System.IO.Ports;
using System.Net.Sockets;
using System.Net;
using System.Windows.Forms;


namespace Demo
{

	public class HKRAR_EM
	{
        enum recvTempState
        {
            start,
            data,
            end
        }

		#region Members
		Form1 m_form;

		#endregion

		#region Functions

        private TcpClient tcpClient = new TcpClient();
        private Socket sock;



        byte[] gComBuffer = new byte[2048];
		int gDatalength = 0;
       				
		int sStartIdx	= 0;
		byte sBt		= 0x00;

		public HKRAR_EM(	
							Form1 form,
							string hostname, int port)
		{
			m_form = form;

            try
            {
                tcpClient.Connect(hostname, port);
                if (tcpClient != null)
                {
                    m_form.Invoke(new Action<string>(m_form.setStatus), new Object[] { "Connected" });
                    m_form.Invoke(new Action<bool>(m_form.setConnected), new Object[] { true });
                    sock = tcpClient.Client;
                }else
                {                 
                }
                return;



            }
            catch
            {
                      m_form.Invoke(new Action<string>(m_form.setStatus), new Object[] { "Connect Fail" });                
            }
		}



        public void Run()
        {
            while (true)
            {
                string s = "";
                byte[] byteArray1 = null;
                int rsize = 0;
                Thread.Sleep(1);
                if (sock == null || sock.Connected == false)
                {                    
                    return;
                }
                int iBytes2Read = sock.Available;
                if (iBytes2Read > 0)
                {
                    byteArray1 = new byte[iBytes2Read];
                    rsize = sock.Receive(byteArray1, 0, iBytes2Read, SocketFlags.None);

                    string disp = BitConverter.ToString(byteArray1);
                }



                if (byteArray1 != null)
                {
                    if (rsize > 0)
                    {
                        s = "";
                        byte[] bs = new byte[gDatalength + rsize];

                         if (gDatalength > 0)
                        {
                            Array.Copy(gComBuffer, 0, bs, 0, gDatalength);
                        }
                        Array.Copy(byteArray1, 0, bs, gDatalength, rsize);
                        if (gDatalength > 0)
                        {
                            gDatalength = 0;
                        }

                        sStartIdx = -1;

                        for (int i = 0; i < bs.Length; i++)
                        {
                            int sPackLen = 0;

                            if (bs[i] == 0x02) 
                            {
                                if (bs.Length >= i + 2)
                                {
                                    sPackLen = bs[i + 1];
                                }

                                sStartIdx = i;
                        
                                if ((bs.Length - i) >= sPackLen && bs.Length != 1 && i != bs.Length - 1)
                                {

                                    if (bs[sStartIdx + sPackLen - 1] == 0x03)
                                    {
                                        sBt = 0x00;
                                        for (int j = 0; j < sPackLen - 2; j++)
                                        {
                                            sBt = (byte)((sBt ^ bs[i + j]));
                                        }

                                        if ((byte)sBt == (byte)bs[sStartIdx + sPackLen - 2])
                                        {
                                            switch (bs[sStartIdx + 2])
                                            {

                                                case 0x01:
                                                    s = (bs[sStartIdx + 03]).ToString();

                                                    m_form.Invoke(m_form.m_DelegateAddMsg, new Object[] { 1, "Get Gain:" + s });
                                                    //m_form.Invoke(m_form.m_DelegateSetGainLabel, new Object[] { bs[i + 3] });
                                                    break;
                                                case 0x02:
                                                    s = (bs[sStartIdx + 03]).ToString();

                                                    m_form.Invoke(m_form.m_DelegateAddMsg, new Object[] { 1, "Set Gain:" + s });
                                                    //m_form.Invoke(m_form.m_DelegateSetGainLabel, new Object[] { bs[i + 3] });
                                                    break;

                                                case 0x06:
                                                    s = "";
                                                    for (int k = 0; k < 8; k++) //8 bytes for tagID
                                                    {
                                                        s = s + bs[i + 3 + k].ToString("X2") + " ";
                                                    }
                                                   m_form.Invoke(new Action<string, int>(m_form.addTagRecord), new Object[] { s, bs[i + sPackLen - 3] });
                                                    break;
                                                case 0x07:
                                                     if (bs[sStartIdx + 3] == 0x00)
                                                    {
                                                        m_form.Invoke(new Action<bool>(m_form.setReading), new Object[] { false });
                                                    }
                                                    else
                                                    {
                                                       m_form.Invoke(new Action<bool>(m_form.setReading), new Object[] { true });
                                                    }
                                                    break;
                                                case 0x0C:
                                                    s = (bs[sStartIdx + 03]).ToString("X2");
                                                    m_form.Invoke(m_form.m_DelegateAddMsg, new Object[] { 1, "Reader Version: " + s });
                                                    break;
                                        

                                            }
                                        }
                                    }
                                    i = sStartIdx + sPackLen - 2;
                                }
                                else
                                {	
                                    Array.Copy(bs, i, gComBuffer, 0, bs.Length - i);
                                    gDatalength = bs.Length - i;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }



        private void sendPacket(byte[] buf, int offset, int length)
        {
            try
            {
                sock.Send(buf, offset, length, SocketFlags.None);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public int StartRead()
        {
            //0x02     0x06     0x07     0x01      0x02       0x03
            byte[] sBuf = new byte[] { 0x02, 0x06, 0x07, 0x01, 0x02, 0x03 };
            sendPacket(sBuf, 0, sBuf.Length);
            return 0;
        }

        public int StopRead()
        {
            //0x02     0x06     0x07     0x00      0x03       0x03
            byte[] sBuf = new byte[] { 0x02, 0x06, 0x07, 0x00, 0x03, 0x03 };
            sendPacket(sBuf, 0, sBuf.Length);
            return 0;
        }

        public int GetGain()
        {
            //02 05 01 06 03
            byte[] sBuf = new byte[] { 0x02, 0x05, 0x01, 0x06, 0x03 };
            sendPacket(sBuf, 0, sBuf.Length);
            return 0;
        }

        public int SetGain(byte pGain)
        {

            //02 06 02 XX CS 03

            byte[] sBuf = new byte[] { 0x02, 0x06, 0x02, 0x00, 0xBB, 0x03 };
            byte sSum = 0x00;

            sBuf[3] = pGain;
            for (int i = 0; i < sBuf.Length - 2; i++)
            {
                sSum = (byte)(sSum ^ sBuf[i]);
            }

            sBuf[4] = sSum;

            sendPacket(sBuf, 0, sBuf.Length);
            return 0;
        }

		public static byte[] StringToByteArray(String hex)
		{   
			int NumberChars = hex.Length;
			byte[] bytes = new byte[NumberChars / 2];
			for (int i = 0; i < NumberChars; i += 2)
				bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
			return bytes;
		}

        public void getReaderVersion()
        {
            //0x02     0x05     0x0C    [CS]   0x03
            byte[] sBuf = new byte[5];
            int idx = 0;
            byte sSum = 0x00;

            //header
            sBuf[idx++] = 0x02;
            //size
            sBuf[idx++] = 0x05;
            //
            sBuf[idx++] = 0x0C;
            //calc checksum
            for (int i = 0; i < idx; i++)
            {
                sSum = (byte)(sSum ^ sBuf[i]);
            }
            sBuf[idx++] = sSum;
            //footer
            sBuf[idx++] = 0x03;
            sendPacket(sBuf, 0, sBuf.Length);
            return;
        }

        private string removeSpace(string x)
        {
            x = x.Replace(" ", "");
            return x;
        }

		public void ClosePort()
		{            
            if (tcpClient != null)
            {
                tcpClient.Close();
                m_form.Invoke(new Action<string>(m_form.setStatus), new Object[] { "Disconnected" });
                m_form.Invoke(new Action<bool>(m_form.setConnected), new Object[] { false });
                tcpClient = null;
            }


        }


		~HKRAR_EM()
		{
            if (tcpClient != null)
            {
                tcpClient.Close();
                tcpClient = null;
            }

		}

		#endregion	
	}
}
