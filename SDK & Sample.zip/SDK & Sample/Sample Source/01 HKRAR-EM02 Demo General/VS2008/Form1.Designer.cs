﻿namespace Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnConn = new System.Windows.Forms.Button();
            this.rbTcp = new System.Windows.Forms.RadioButton();
            this.tbHostName = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comboBox_comport = new System.Windows.Forms.ComboBox();
            this.rbCom = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel_TagList = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.btnClear = new System.Windows.Forms.Button();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbReturnNum = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnClearBuffer = new System.Windows.Forms.Button();
            this.btnGetNClaer = new System.Windows.Forms.Button();
            this.btnGetTagBuffer = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnGetReaderVersion = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.cbAutoGetStatus = new System.Windows.Forms.CheckBox();
            this.tbEM02Result = new System.Windows.Forms.TextBox();
            this.cbHeartBeat = new System.Windows.Forms.CheckBox();
            this.cbSystemTime = new System.Windows.Forms.CheckBox();
            this.tbReaderTime = new System.Windows.Forms.TextBox();
            this.cbRequestMode = new System.Windows.Forms.ComboBox();
            this.cbReaderMode = new System.Windows.Forms.ComboBox();
            this.btnResetReader = new System.Windows.Forms.Button();
            this.btnSetHB = new System.Windows.Forms.Button();
            this.btnSetReaderTime = new System.Windows.Forms.Button();
            this.btnSetReqMode = new System.Windows.Forms.Button();
            this.btnSetReaderMode = new System.Windows.Forms.Button();
            this.btnGetSn = new System.Windows.Forms.Button();
            this.btnGetReaderStatus = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGetSecuredSN = new System.Windows.Forms.Button();
            this.btnLEDBuzzer = new System.Windows.Forms.Button();
            this.btnReaderBuzzer = new System.Windows.Forms.Button();
            this.btnReaderLED = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.setVal3 = new System.Windows.Forms.CheckBox();
            this.setVal2 = new System.Windows.Forms.CheckBox();
            this.setVal1 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.setValMask3 = new System.Windows.Forms.CheckBox();
            this.setValMask2 = new System.Windows.Forms.CheckBox();
            this.setValMask1 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.setDir3 = new System.Windows.Forms.CheckBox();
            this.setDir2 = new System.Windows.Forms.CheckBox();
            this.setDir1 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.setDirMask3 = new System.Windows.Forms.CheckBox();
            this.setDirMask2 = new System.Windows.Forms.CheckBox();
            this.setDirMask1 = new System.Windows.Forms.CheckBox();
            this.btnSetGPIOVal = new System.Windows.Forms.Button();
            this.btnGPIODir = new System.Windows.Forms.Button();
            this.cbSampleTime = new System.Windows.Forms.ComboBox();
            this.btnSetSampleTime = new System.Windows.Forms.Button();
            this.cbReaderFrequency = new System.Windows.Forms.ComboBox();
            this.cbReaderChannel = new System.Windows.Forms.ComboBox();
            this.btnSetReaderFrequency = new System.Windows.Forms.Button();
            this.btnSetReaderChannel = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tbAtag = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbTag = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbGain = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.timerHealth = new System.Windows.Forms.Timer(this.components);
            this.timerUI = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel_menuStrip = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectionTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.serialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tCPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.modeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.versionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.demoProgramVerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.libraryVerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel_TagList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel_menuStrip.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(865, 606);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.btnConn);
            this.panel1.Controls.Add(this.rbTcp);
            this.panel1.Controls.Add(this.tbHostName);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.comboBox_comport);
            this.panel1.Controls.Add(this.rbCom);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(859, 53);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnConn
            // 
            this.btnConn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnConn.Location = new System.Drawing.Point(273, 12);
            this.btnConn.Name = "btnConn";
            this.btnConn.Size = new System.Drawing.Size(120, 33);
            this.btnConn.TabIndex = 33;
            this.btnConn.Text = "Connect Reader";
            this.btnConn.UseVisualStyleBackColor = false;
            this.btnConn.Click += new System.EventHandler(this.btnConn_Click);
            // 
            // rbTcp
            // 
            this.rbTcp.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rbTcp.AutoSize = true;
            this.rbTcp.Checked = true;
            this.rbTcp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbTcp.Location = new System.Drawing.Point(47, 18);
            this.rbTcp.Name = "rbTcp";
            this.rbTcp.Size = new System.Drawing.Size(53, 17);
            this.rbTcp.TabIndex = 32;
            this.rbTcp.TabStop = true;
            this.rbTcp.Text = "TCP:";
            this.rbTcp.UseVisualStyleBackColor = true;
            this.rbTcp.Visible = false;
            // 
            // tbHostName
            // 
            this.tbHostName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tbHostName.BackColor = System.Drawing.Color.White;
            this.tbHostName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHostName.Location = new System.Drawing.Point(106, 18);
            this.tbHostName.Name = "tbHostName";
            this.tbHostName.Size = new System.Drawing.Size(157, 20);
            this.tbHostName.TabIndex = 31;
            this.tbHostName.Text = "192.168.1.254";
            this.tbHostName.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = global::Demo.Properties.Resources.hk_rfid_logo;
            this.pictureBox1.Location = new System.Drawing.Point(658, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(198, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // comboBox_comport
            // 
            this.comboBox_comport.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.comboBox_comport.BackColor = System.Drawing.Color.White;
            this.comboBox_comport.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.comboBox_comport.FormattingEnabled = true;
            this.comboBox_comport.Location = new System.Drawing.Point(106, 17);
            this.comboBox_comport.Name = "comboBox_comport";
            this.comboBox_comport.Size = new System.Drawing.Size(161, 21);
            this.comboBox_comport.TabIndex = 26;
            this.comboBox_comport.Click += new System.EventHandler(this.comboBox1_Click);
            // 
            // rbCom
            // 
            this.rbCom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.rbCom.AutoSize = true;
            this.rbCom.Checked = true;
            this.rbCom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCom.Location = new System.Drawing.Point(13, 20);
            this.rbCom.Name = "rbCom";
            this.rbCom.Size = new System.Drawing.Size(88, 17);
            this.rbCom.TabIndex = 29;
            this.rbCom.TabStop = true;
            this.rbCom.Text = "Serial Port:";
            this.rbCom.UseVisualStyleBackColor = true;
            this.rbCom.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(859, 540);
            this.panel2.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.88009F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 83.1199F));
            this.tableLayoutPanel2.Controls.Add(this.tabControl1, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(859, 540);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(145, 1);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(713, 538);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage1.Controls.Add(this.tableLayoutPanel_TagList);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage1.Size = new System.Drawing.Size(705, 509);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Reader Result";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel_TagList
            // 
            this.tableLayoutPanel_TagList.ColumnCount = 1;
            this.tableLayoutPanel_TagList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_TagList.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel_TagList.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel_TagList.Controls.Add(this.tableLayoutPanel4, 0, 2);
            this.tableLayoutPanel_TagList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_TagList.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel_TagList.Name = "tableLayoutPanel_TagList";
            this.tableLayoutPanel_TagList.RowCount = 3;
            this.tableLayoutPanel_TagList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel_TagList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_TagList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel_TagList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel_TagList.Size = new System.Drawing.Size(703, 507);
            this.tableLayoutPanel_TagList.TabIndex = 3;
            this.tableLayoutPanel_TagList.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel_TagList_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 57);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(697, 404);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 5;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.875F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.125F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 179F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 144F));
            this.tableLayoutPanel8.Controls.Add(this.btnClear, 4, 0);
            this.tableLayoutPanel8.Controls.Add(this.comboBox4, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.comboBox3, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.lbReturnNum, 3, 1);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.36364F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 63.63636F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(697, 48);
            this.tableLayoutPanel8.TabIndex = 8;
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClear.FlatAppearance.BorderSize = 3;
            this.btnClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnClear.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(555, 6);
            this.btnClear.Name = "btnClear";
            this.tableLayoutPanel8.SetRowSpan(this.btnClear, 2);
            this.btnClear.Size = new System.Drawing.Size(139, 36);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "Clear Result";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // comboBox4
            // 
            this.comboBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "All",
            "Normal",
            "Low"});
            this.comboBox4.Location = new System.Drawing.Point(117, 20);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(123, 21);
            this.comboBox4.TabIndex = 2;
            this.comboBox4.Text = "All";
            // 
            // comboBox3
            // 
            this.comboBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "All",
            "High",
            "Low"});
            this.comboBox3.Location = new System.Drawing.Point(3, 20);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(108, 21);
            this.comboBox3.TabIndex = 1;
            this.comboBox3.Text = "All";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(117, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Battery Status:";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Signal Strength:";
            // 
            // lbReturnNum
            // 
            this.lbReturnNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbReturnNum.AutoSize = true;
            this.lbReturnNum.Location = new System.Drawing.Point(425, 35);
            this.lbReturnNum.Name = "lbReturnNum";
            this.lbReturnNum.Size = new System.Drawing.Size(56, 13);
            this.lbReturnNum.TabIndex = 9;
            this.lbReturnNum.Text = "Returning:";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.Controls.Add(this.btnClearBuffer, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnGetNClaer, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnGetTagBuffer, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 467);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(697, 37);
            this.tableLayoutPanel4.TabIndex = 9;
            // 
            // btnClearBuffer
            // 
            this.btnClearBuffer.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClearBuffer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnClearBuffer.Location = new System.Drawing.Point(467, 3);
            this.btnClearBuffer.Name = "btnClearBuffer";
            this.btnClearBuffer.Size = new System.Drawing.Size(227, 30);
            this.btnClearBuffer.TabIndex = 9;
            this.btnClearBuffer.Text = "Clear Reader Buffer";
            this.btnClearBuffer.UseVisualStyleBackColor = false;
            this.btnClearBuffer.Click += new System.EventHandler(this.btnClearBuffer_Click);
            // 
            // btnGetNClaer
            // 
            this.btnGetNClaer.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGetNClaer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnGetNClaer.Location = new System.Drawing.Point(235, 3);
            this.btnGetNClaer.Name = "btnGetNClaer";
            this.btnGetNClaer.Size = new System.Drawing.Size(220, 30);
            this.btnGetNClaer.TabIndex = 8;
            this.btnGetNClaer.Text = "Get and Clear Reader Buffer";
            this.btnGetNClaer.UseVisualStyleBackColor = false;
            this.btnGetNClaer.Click += new System.EventHandler(this.btnGetNClaer_Click);
            // 
            // btnGetTagBuffer
            // 
            this.btnGetTagBuffer.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGetTagBuffer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnGetTagBuffer.Location = new System.Drawing.Point(3, 3);
            this.btnGetTagBuffer.Name = "btnGetTagBuffer";
            this.btnGetTagBuffer.Size = new System.Drawing.Size(220, 30);
            this.btnGetTagBuffer.TabIndex = 7;
            this.btnGetTagBuffer.Text = "Get Reader Buffer";
            this.btnGetTagBuffer.UseVisualStyleBackColor = false;
            this.btnGetTagBuffer.Click += new System.EventHandler(this.btnGetTagBuffer_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage2.Controls.Add(this.btnGetReaderVersion);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.cbAutoGetStatus);
            this.tabPage2.Controls.Add(this.tbEM02Result);
            this.tabPage2.Controls.Add(this.cbHeartBeat);
            this.tabPage2.Controls.Add(this.cbSystemTime);
            this.tabPage2.Controls.Add(this.tbReaderTime);
            this.tabPage2.Controls.Add(this.cbRequestMode);
            this.tabPage2.Controls.Add(this.cbReaderMode);
            this.tabPage2.Controls.Add(this.btnResetReader);
            this.tabPage2.Controls.Add(this.btnSetHB);
            this.tabPage2.Controls.Add(this.btnSetReaderTime);
            this.tabPage2.Controls.Add(this.btnSetReqMode);
            this.tabPage2.Controls.Add(this.btnSetReaderMode);
            this.tabPage2.Controls.Add(this.btnGetSn);
            this.tabPage2.Controls.Add(this.btnGetReaderStatus);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(705, 509);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Reader Setting";
            // 
            // btnGetReaderVersion
            // 
            this.btnGetReaderVersion.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnGetReaderVersion.Location = new System.Drawing.Point(6, 108);
            this.btnGetReaderVersion.Name = "btnGetReaderVersion";
            this.btnGetReaderVersion.Size = new System.Drawing.Size(120, 33);
            this.btnGetReaderVersion.TabIndex = 25;
            this.btnGetReaderVersion.Text = "Get Reader Version";
            this.btnGetReaderVersion.UseVisualStyleBackColor = false;
            this.btnGetReaderVersion.Click += new System.EventHandler(this.btnGetReaderVersion_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button8.Location = new System.Drawing.Point(6, 270);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(120, 35);
            this.button8.TabIndex = 24;
            this.button8.Text = "Get Gain";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.btnGetGain_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button7.Location = new System.Drawing.Point(6, 219);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(120, 36);
            this.button7.TabIndex = 23;
            this.button7.Text = "Set Gain";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.btnSetGain_Click);
            // 
            // cbAutoGetStatus
            // 
            this.cbAutoGetStatus.AutoSize = true;
            this.cbAutoGetStatus.Location = new System.Drawing.Point(30, 46);
            this.cbAutoGetStatus.Name = "cbAutoGetStatus";
            this.cbAutoGetStatus.Size = new System.Drawing.Size(101, 17);
            this.cbAutoGetStatus.TabIndex = 22;
            this.cbAutoGetStatus.Text = "Auto Get Status";
            this.cbAutoGetStatus.UseVisualStyleBackColor = true;
            // 
            // tbEM02Result
            // 
            this.tbEM02Result.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEM02Result.Location = new System.Drawing.Point(132, 8);
            this.tbEM02Result.Multiline = true;
            this.tbEM02Result.Name = "tbEM02Result";
            this.tbEM02Result.Size = new System.Drawing.Size(557, 194);
            this.tbEM02Result.TabIndex = 21;
            // 
            // cbHeartBeat
            // 
            this.cbHeartBeat.AutoSize = true;
            this.cbHeartBeat.Location = new System.Drawing.Point(132, 386);
            this.cbHeartBeat.Name = "cbHeartBeat";
            this.cbHeartBeat.Size = new System.Drawing.Size(58, 17);
            this.cbHeartBeat.TabIndex = 20;
            this.cbHeartBeat.Text = "enable";
            this.cbHeartBeat.UseVisualStyleBackColor = true;
            // 
            // cbSystemTime
            // 
            this.cbSystemTime.AutoSize = true;
            this.cbSystemTime.Checked = true;
            this.cbSystemTime.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbSystemTime.Location = new System.Drawing.Point(281, 341);
            this.cbSystemTime.Name = "cbSystemTime";
            this.cbSystemTime.Size = new System.Drawing.Size(108, 17);
            this.cbSystemTime.TabIndex = 19;
            this.cbSystemTime.Text = "Use System Time";
            this.cbSystemTime.UseVisualStyleBackColor = true;
            this.cbSystemTime.CheckedChanged += new System.EventHandler(this.cbSystemTime_CheckedChanged);
            // 
            // tbReaderTime
            // 
            this.tbReaderTime.Enabled = false;
            this.tbReaderTime.Location = new System.Drawing.Point(132, 337);
            this.tbReaderTime.Name = "tbReaderTime";
            this.tbReaderTime.Size = new System.Drawing.Size(143, 20);
            this.tbReaderTime.TabIndex = 18;
            // 
            // cbRequestMode
            // 
            this.cbRequestMode.FormattingEnabled = true;
            this.cbRequestMode.Items.AddRange(new object[] {
            "Active (default)",
            "Passive"});
            this.cbRequestMode.Location = new System.Drawing.Point(521, 278);
            this.cbRequestMode.Name = "cbRequestMode";
            this.cbRequestMode.Size = new System.Drawing.Size(120, 21);
            this.cbRequestMode.TabIndex = 11;
            // 
            // cbReaderMode
            // 
            this.cbReaderMode.FormattingEnabled = true;
            this.cbReaderMode.Items.AddRange(new object[] {
            "EM02Mode(default)",
            "Classic"});
            this.cbReaderMode.Location = new System.Drawing.Point(521, 229);
            this.cbReaderMode.Name = "cbReaderMode";
            this.cbReaderMode.Size = new System.Drawing.Size(120, 21);
            this.cbReaderMode.TabIndex = 10;
            // 
            // btnResetReader
            // 
            this.btnResetReader.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnResetReader.Location = new System.Drawing.Point(6, 426);
            this.btnResetReader.Name = "btnResetReader";
            this.btnResetReader.Size = new System.Drawing.Size(120, 33);
            this.btnResetReader.TabIndex = 9;
            this.btnResetReader.Text = "Reset Reader";
            this.btnResetReader.UseVisualStyleBackColor = false;
            this.btnResetReader.Click += new System.EventHandler(this.btnResetReader_Click);
            // 
            // btnSetHB
            // 
            this.btnSetHB.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSetHB.Location = new System.Drawing.Point(6, 377);
            this.btnSetHB.Name = "btnSetHB";
            this.btnSetHB.Size = new System.Drawing.Size(120, 33);
            this.btnSetHB.TabIndex = 8;
            this.btnSetHB.Text = "Set HeartBeat";
            this.btnSetHB.UseVisualStyleBackColor = false;
            this.btnSetHB.Click += new System.EventHandler(this.btnSetHB_Click);
            // 
            // btnSetReaderTime
            // 
            this.btnSetReaderTime.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSetReaderTime.Location = new System.Drawing.Point(6, 330);
            this.btnSetReaderTime.Name = "btnSetReaderTime";
            this.btnSetReaderTime.Size = new System.Drawing.Size(120, 33);
            this.btnSetReaderTime.TabIndex = 7;
            this.btnSetReaderTime.Text = "Set Reader Time";
            this.btnSetReaderTime.UseVisualStyleBackColor = false;
            this.btnSetReaderTime.Click += new System.EventHandler(this.btnSetReaderTime_Click);
            // 
            // btnSetReqMode
            // 
            this.btnSetReqMode.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSetReqMode.Location = new System.Drawing.Point(386, 272);
            this.btnSetReqMode.Name = "btnSetReqMode";
            this.btnSetReqMode.Size = new System.Drawing.Size(120, 33);
            this.btnSetReqMode.TabIndex = 4;
            this.btnSetReqMode.Text = "Set Request Mode";
            this.btnSetReqMode.UseVisualStyleBackColor = false;
            this.btnSetReqMode.Click += new System.EventHandler(this.btnSetReqMode_Click);
            // 
            // btnSetReaderMode
            // 
            this.btnSetReaderMode.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSetReaderMode.Location = new System.Drawing.Point(386, 222);
            this.btnSetReaderMode.Name = "btnSetReaderMode";
            this.btnSetReaderMode.Size = new System.Drawing.Size(120, 33);
            this.btnSetReaderMode.TabIndex = 3;
            this.btnSetReaderMode.Text = "Set Reader Mode";
            this.btnSetReaderMode.UseVisualStyleBackColor = false;
            this.btnSetReaderMode.Click += new System.EventHandler(this.btnSetReaderMode_Click);
            // 
            // btnGetSn
            // 
            this.btnGetSn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnGetSn.Location = new System.Drawing.Point(6, 69);
            this.btnGetSn.Name = "btnGetSn";
            this.btnGetSn.Size = new System.Drawing.Size(120, 33);
            this.btnGetSn.TabIndex = 2;
            this.btnGetSn.Text = "Get SN";
            this.btnGetSn.UseVisualStyleBackColor = false;
            this.btnGetSn.Click += new System.EventHandler(this.btnGetSn_Click);
            // 
            // btnGetReaderStatus
            // 
            this.btnGetReaderStatus.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnGetReaderStatus.Location = new System.Drawing.Point(6, 7);
            this.btnGetReaderStatus.Name = "btnGetReaderStatus";
            this.btnGetReaderStatus.Size = new System.Drawing.Size(120, 33);
            this.btnGetReaderStatus.TabIndex = 0;
            this.btnGetReaderStatus.Text = "Get Reader Status";
            this.btnGetReaderStatus.UseVisualStyleBackColor = false;
            this.btnGetReaderStatus.Click += new System.EventHandler(this.btnGetReaderStatus_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.btnGetSecuredSN);
            this.tabPage3.Controls.Add(this.btnLEDBuzzer);
            this.tabPage3.Controls.Add(this.btnReaderBuzzer);
            this.tabPage3.Controls.Add(this.btnReaderLED);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.btnSetGPIOVal);
            this.tabPage3.Controls.Add(this.btnGPIODir);
            this.tabPage3.Controls.Add(this.cbSampleTime);
            this.tabPage3.Controls.Add(this.btnSetSampleTime);
            this.tabPage3.Controls.Add(this.cbReaderFrequency);
            this.tabPage3.Controls.Add(this.cbReaderChannel);
            this.tabPage3.Controls.Add(this.btnSetReaderFrequency);
            this.tabPage3.Controls.Add(this.btnSetReaderChannel);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(705, 509);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Advanced Setting";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(474, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 13);
            this.label8.TabIndex = 46;
            this.label8.Text = "* tick to set \"In\" direction";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(474, 228);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 13);
            this.label1.TabIndex = 45;
            this.label1.Text = "* tick to set \"high\" value";
            // 
            // btnGetSecuredSN
            // 
            this.btnGetSecuredSN.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnGetSecuredSN.Location = new System.Drawing.Point(21, 437);
            this.btnGetSecuredSN.Name = "btnGetSecuredSN";
            this.btnGetSecuredSN.Size = new System.Drawing.Size(120, 33);
            this.btnGetSecuredSN.TabIndex = 44;
            this.btnGetSecuredSN.Text = "Get SN (secured)";
            this.btnGetSecuredSN.UseVisualStyleBackColor = false;
            this.btnGetSecuredSN.Visible = false;
            // 
            // btnLEDBuzzer
            // 
            this.btnLEDBuzzer.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnLEDBuzzer.Location = new System.Drawing.Point(21, 381);
            this.btnLEDBuzzer.Name = "btnLEDBuzzer";
            this.btnLEDBuzzer.Size = new System.Drawing.Size(120, 33);
            this.btnLEDBuzzer.TabIndex = 43;
            this.btnLEDBuzzer.Text = "Reader LED+Buzzer";
            this.btnLEDBuzzer.UseVisualStyleBackColor = false;
            this.btnLEDBuzzer.Click += new System.EventHandler(this.btnLEDBuzzer_Click);
            // 
            // btnReaderBuzzer
            // 
            this.btnReaderBuzzer.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnReaderBuzzer.Location = new System.Drawing.Point(21, 326);
            this.btnReaderBuzzer.Name = "btnReaderBuzzer";
            this.btnReaderBuzzer.Size = new System.Drawing.Size(120, 33);
            this.btnReaderBuzzer.TabIndex = 42;
            this.btnReaderBuzzer.Text = "Reader Buzzer";
            this.btnReaderBuzzer.UseVisualStyleBackColor = false;
            this.btnReaderBuzzer.Click += new System.EventHandler(this.btnReaderBuzzer_Click_1);
            // 
            // btnReaderLED
            // 
            this.btnReaderLED.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnReaderLED.Location = new System.Drawing.Point(21, 276);
            this.btnReaderLED.Name = "btnReaderLED";
            this.btnReaderLED.Size = new System.Drawing.Size(120, 33);
            this.btnReaderLED.TabIndex = 41;
            this.btnReaderLED.Text = "Reader LED Flash";
            this.btnReaderLED.UseVisualStyleBackColor = false;
            this.btnReaderLED.Click += new System.EventHandler(this.btnReaderLED_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.setVal3);
            this.groupBox3.Controls.Add(this.setVal2);
            this.groupBox3.Controls.Add(this.setVal1);
            this.groupBox3.Location = new System.Drawing.Point(325, 216);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(143, 46);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Value";
            // 
            // setVal3
            // 
            this.setVal3.AutoSize = true;
            this.setVal3.Location = new System.Drawing.Point(96, 20);
            this.setVal3.Name = "setVal3";
            this.setVal3.Size = new System.Drawing.Size(39, 17);
            this.setVal3.TabIndex = 14;
            this.setVal3.Text = "P3";
            this.setVal3.UseVisualStyleBackColor = true;
            // 
            // setVal2
            // 
            this.setVal2.AutoSize = true;
            this.setVal2.Location = new System.Drawing.Point(51, 20);
            this.setVal2.Name = "setVal2";
            this.setVal2.Size = new System.Drawing.Size(39, 17);
            this.setVal2.TabIndex = 13;
            this.setVal2.Text = "P2";
            this.setVal2.UseVisualStyleBackColor = true;
            // 
            // setVal1
            // 
            this.setVal1.AutoSize = true;
            this.setVal1.Location = new System.Drawing.Point(6, 20);
            this.setVal1.Name = "setVal1";
            this.setVal1.Size = new System.Drawing.Size(39, 17);
            this.setVal1.TabIndex = 12;
            this.setVal1.Text = "P1";
            this.setVal1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.setValMask3);
            this.groupBox4.Controls.Add(this.setValMask2);
            this.groupBox4.Controls.Add(this.setValMask1);
            this.groupBox4.Location = new System.Drawing.Point(164, 216);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(143, 46);
            this.groupBox4.TabIndex = 39;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Mask";
            // 
            // setValMask3
            // 
            this.setValMask3.AutoSize = true;
            this.setValMask3.Location = new System.Drawing.Point(96, 20);
            this.setValMask3.Name = "setValMask3";
            this.setValMask3.Size = new System.Drawing.Size(39, 17);
            this.setValMask3.TabIndex = 14;
            this.setValMask3.Text = "P3";
            this.setValMask3.UseVisualStyleBackColor = true;
            // 
            // setValMask2
            // 
            this.setValMask2.AutoSize = true;
            this.setValMask2.Location = new System.Drawing.Point(51, 20);
            this.setValMask2.Name = "setValMask2";
            this.setValMask2.Size = new System.Drawing.Size(39, 17);
            this.setValMask2.TabIndex = 13;
            this.setValMask2.Text = "P2";
            this.setValMask2.UseVisualStyleBackColor = true;
            // 
            // setValMask1
            // 
            this.setValMask1.AutoSize = true;
            this.setValMask1.Location = new System.Drawing.Point(6, 20);
            this.setValMask1.Name = "setValMask1";
            this.setValMask1.Size = new System.Drawing.Size(39, 17);
            this.setValMask1.TabIndex = 12;
            this.setValMask1.Text = "P1";
            this.setValMask1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.setDir3);
            this.groupBox2.Controls.Add(this.setDir2);
            this.groupBox2.Controls.Add(this.setDir1);
            this.groupBox2.Location = new System.Drawing.Point(325, 164);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(143, 46);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Direction";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // setDir3
            // 
            this.setDir3.AutoSize = true;
            this.setDir3.Location = new System.Drawing.Point(96, 20);
            this.setDir3.Name = "setDir3";
            this.setDir3.Size = new System.Drawing.Size(39, 17);
            this.setDir3.TabIndex = 14;
            this.setDir3.Text = "P3";
            this.setDir3.UseVisualStyleBackColor = true;
            // 
            // setDir2
            // 
            this.setDir2.AutoSize = true;
            this.setDir2.Location = new System.Drawing.Point(51, 20);
            this.setDir2.Name = "setDir2";
            this.setDir2.Size = new System.Drawing.Size(39, 17);
            this.setDir2.TabIndex = 13;
            this.setDir2.Text = "P2";
            this.setDir2.UseVisualStyleBackColor = true;
            // 
            // setDir1
            // 
            this.setDir1.AutoSize = true;
            this.setDir1.Location = new System.Drawing.Point(6, 20);
            this.setDir1.Name = "setDir1";
            this.setDir1.Size = new System.Drawing.Size(39, 17);
            this.setDir1.TabIndex = 12;
            this.setDir1.Text = "P1";
            this.setDir1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.setDirMask3);
            this.groupBox1.Controls.Add(this.setDirMask2);
            this.groupBox1.Controls.Add(this.setDirMask1);
            this.groupBox1.Location = new System.Drawing.Point(164, 164);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(143, 46);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mask";
            // 
            // setDirMask3
            // 
            this.setDirMask3.AutoSize = true;
            this.setDirMask3.Location = new System.Drawing.Point(96, 20);
            this.setDirMask3.Name = "setDirMask3";
            this.setDirMask3.Size = new System.Drawing.Size(39, 17);
            this.setDirMask3.TabIndex = 14;
            this.setDirMask3.Text = "P3";
            this.setDirMask3.UseVisualStyleBackColor = true;
            // 
            // setDirMask2
            // 
            this.setDirMask2.AutoSize = true;
            this.setDirMask2.Location = new System.Drawing.Point(51, 20);
            this.setDirMask2.Name = "setDirMask2";
            this.setDirMask2.Size = new System.Drawing.Size(39, 17);
            this.setDirMask2.TabIndex = 13;
            this.setDirMask2.Text = "P2";
            this.setDirMask2.UseVisualStyleBackColor = true;
            // 
            // setDirMask1
            // 
            this.setDirMask1.AutoSize = true;
            this.setDirMask1.Location = new System.Drawing.Point(6, 20);
            this.setDirMask1.Name = "setDirMask1";
            this.setDirMask1.Size = new System.Drawing.Size(39, 17);
            this.setDirMask1.TabIndex = 12;
            this.setDirMask1.Text = "P1";
            this.setDirMask1.UseVisualStyleBackColor = true;
            // 
            // btnSetGPIOVal
            // 
            this.btnSetGPIOVal.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSetGPIOVal.Location = new System.Drawing.Point(21, 228);
            this.btnSetGPIOVal.Name = "btnSetGPIOVal";
            this.btnSetGPIOVal.Size = new System.Drawing.Size(120, 33);
            this.btnSetGPIOVal.TabIndex = 36;
            this.btnSetGPIOVal.Text = "Set GPIO Value";
            this.btnSetGPIOVal.UseVisualStyleBackColor = false;
            this.btnSetGPIOVal.Click += new System.EventHandler(this.btnSetGPIOVal_Click);
            // 
            // btnGPIODir
            // 
            this.btnGPIODir.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGPIODir.Location = new System.Drawing.Point(21, 177);
            this.btnGPIODir.Name = "btnGPIODir";
            this.btnGPIODir.Size = new System.Drawing.Size(120, 33);
            this.btnGPIODir.TabIndex = 35;
            this.btnGPIODir.Text = "Set GPIO Direction";
            this.btnGPIODir.UseVisualStyleBackColor = false;
            this.btnGPIODir.Click += new System.EventHandler(this.btnGPIODir_Click);
            // 
            // cbSampleTime
            // 
            this.cbSampleTime.FormattingEnabled = true;
            this.cbSampleTime.Items.AddRange(new object[] {
            "Short(default)",
            "Long",
            "Instant "});
            this.cbSampleTime.Location = new System.Drawing.Point(147, 116);
            this.cbSampleTime.Name = "cbSampleTime";
            this.cbSampleTime.Size = new System.Drawing.Size(120, 21);
            this.cbSampleTime.TabIndex = 34;
            // 
            // btnSetSampleTime
            // 
            this.btnSetSampleTime.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSetSampleTime.Location = new System.Drawing.Point(21, 109);
            this.btnSetSampleTime.Name = "btnSetSampleTime";
            this.btnSetSampleTime.Size = new System.Drawing.Size(120, 33);
            this.btnSetSampleTime.TabIndex = 33;
            this.btnSetSampleTime.Text = "Set Sample Time";
            this.btnSetSampleTime.UseVisualStyleBackColor = false;
            this.btnSetSampleTime.Click += new System.EventHandler(this.btnSetSampleTime_Click);
            // 
            // cbReaderFrequency
            // 
            this.cbReaderFrequency.FormattingEnabled = true;
            this.cbReaderFrequency.Items.AddRange(new object[] {
            "US (default)",
            "EU"});
            this.cbReaderFrequency.Location = new System.Drawing.Point(147, 66);
            this.cbReaderFrequency.Name = "cbReaderFrequency";
            this.cbReaderFrequency.Size = new System.Drawing.Size(120, 21);
            this.cbReaderFrequency.TabIndex = 32;
            // 
            // cbReaderChannel
            // 
            this.cbReaderChannel.FormattingEnabled = true;
            this.cbReaderChannel.Items.AddRange(new object[] {
            "EM (default)",
            "LX"});
            this.cbReaderChannel.Location = new System.Drawing.Point(147, 22);
            this.cbReaderChannel.Name = "cbReaderChannel";
            this.cbReaderChannel.Size = new System.Drawing.Size(120, 21);
            this.cbReaderChannel.TabIndex = 31;
            // 
            // btnSetReaderFrequency
            // 
            this.btnSetReaderFrequency.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSetReaderFrequency.Location = new System.Drawing.Point(21, 60);
            this.btnSetReaderFrequency.Name = "btnSetReaderFrequency";
            this.btnSetReaderFrequency.Size = new System.Drawing.Size(120, 33);
            this.btnSetReaderFrequency.TabIndex = 30;
            this.btnSetReaderFrequency.Text = "Set Reader Frequency";
            this.btnSetReaderFrequency.UseVisualStyleBackColor = false;
            this.btnSetReaderFrequency.Click += new System.EventHandler(this.btnSetReaderFrequency_Click);
            // 
            // btnSetReaderChannel
            // 
            this.btnSetReaderChannel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSetReaderChannel.Location = new System.Drawing.Point(21, 15);
            this.btnSetReaderChannel.Name = "btnSetReaderChannel";
            this.btnSetReaderChannel.Size = new System.Drawing.Size(120, 33);
            this.btnSetReaderChannel.TabIndex = 29;
            this.btnSetReaderChannel.Text = "Set Reader Channel";
            this.btnSetReaderChannel.UseVisualStyleBackColor = false;
            this.btnSetReaderChannel.Click += new System.EventHandler(this.btnSetReaderChannel_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.btnStart, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel3, 0, 3);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 5;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(138, 534);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.tbAtag, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.panel4, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tbTag, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.tbGain, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label7, 0, 4);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 358);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 6;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(132, 173);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // tbAtag
            // 
            this.tbAtag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbAtag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAtag.Location = new System.Drawing.Point(3, 155);
            this.tbAtag.Name = "tbAtag";
            this.tbAtag.Size = new System.Drawing.Size(126, 20);
            this.tbAtag.TabIndex = 7;
            this.tbAtag.Text = "0";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(126, 27);
            this.panel4.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 18);
            this.label5.TabIndex = 3;
            this.label5.Text = "Gain:";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(95, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 4;
            // 
            // tbTag
            // 
            this.tbTag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbTag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTag.Location = new System.Drawing.Point(3, 105);
            this.tbTag.Name = "tbTag";
            this.tbTag.Size = new System.Drawing.Size(126, 20);
            this.tbTag.TabIndex = 1;
            this.tbTag.Text = "0";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 18);
            this.label4.TabIndex = 2;
            this.label4.Text = "Tag Count:";
            // 
            // tbGain
            // 
            this.tbGain.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbGain.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbGain.Location = new System.Drawing.Point(3, 39);
            this.tbGain.Name = "tbGain";
            this.tbGain.Size = new System.Drawing.Size(126, 20);
            this.tbGain.TabIndex = 0;
            this.tbGain.Text = "0";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Total  Read Count:";
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnStart.FlatAppearance.BorderSize = 3;
            this.btnStart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnStart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnStart.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(3, 13);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(132, 33);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start Read Tag";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 180);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(132, 172);
            this.panel3.TabIndex = 6;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 3;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(132, 172);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // timerHealth
            // 
            this.timerHealth.Interval = 10000;
            this.timerHealth.Tick += new System.EventHandler(this.timerHealth_Tick);
            // 
            // timerUI
            // 
            this.timerUI.Enabled = true;
            this.timerUI.Interval = 1000;
            this.timerUI.Tick += new System.EventHandler(this.timerUI_Tick);
            // 
            // tableLayoutPanel_menuStrip
            // 
            this.tableLayoutPanel_menuStrip.ColumnCount = 1;
            this.tableLayoutPanel_menuStrip.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_menuStrip.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tableLayoutPanel_menuStrip.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel_menuStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_menuStrip.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_menuStrip.Name = "tableLayoutPanel_menuStrip";
            this.tableLayoutPanel_menuStrip.RowCount = 2;
            this.tableLayoutPanel_menuStrip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.599374F));
            this.tableLayoutPanel_menuStrip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 96.40063F));
            this.tableLayoutPanel_menuStrip.Size = new System.Drawing.Size(871, 634);
            this.tableLayoutPanel_menuStrip.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(871, 22);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // optionToolStripMenuItem
            // 
            this.optionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectionTypeToolStripMenuItem,
            this.toolStripSeparator2,
            this.serialToolStripMenuItem,
            this.tCPToolStripMenuItem,
            this.toolStripSeparator3,
            this.modeToolStripMenuItem,
            this.toolStripSeparator4});
            this.optionToolStripMenuItem.Name = "optionToolStripMenuItem";
            this.optionToolStripMenuItem.Size = new System.Drawing.Size(61, 18);
            this.optionToolStripMenuItem.Text = "Options";
            // 
            // connectionTypeToolStripMenuItem
            // 
            this.connectionTypeToolStripMenuItem.Enabled = false;
            this.connectionTypeToolStripMenuItem.Name = "connectionTypeToolStripMenuItem";
            this.connectionTypeToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.connectionTypeToolStripMenuItem.Text = "Connection Type";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(162, 6);
            // 
            // serialToolStripMenuItem
            // 
            this.serialToolStripMenuItem.Checked = true;
            this.serialToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.serialToolStripMenuItem.Name = "serialToolStripMenuItem";
            this.serialToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.serialToolStripMenuItem.Text = "Serial";
            this.serialToolStripMenuItem.Click += new System.EventHandler(this.serialToolStripMenuItem_Click);
            // 
            // tCPToolStripMenuItem
            // 
            this.tCPToolStripMenuItem.Name = "tCPToolStripMenuItem";
            this.tCPToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.tCPToolStripMenuItem.Text = "TCP";
            this.tCPToolStripMenuItem.Click += new System.EventHandler(this.tCPToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(162, 6);
            // 
            // modeToolStripMenuItem
            // 
            this.modeToolStripMenuItem.Enabled = false;
            this.modeToolStripMenuItem.Name = "modeToolStripMenuItem";
            this.modeToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.modeToolStripMenuItem.Text = "Mode";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(162, 6);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.toolStripSeparator1,
            this.versionToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 18);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(134, 6);
            // 
            // versionToolStripMenuItem
            // 
            this.versionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.demoProgramVerToolStripMenuItem,
            this.libraryVerToolStripMenuItem});
            this.versionToolStripMenuItem.Name = "versionToolStripMenuItem";
            this.versionToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.versionToolStripMenuItem.Text = "Version Info";
            // 
            // demoProgramVerToolStripMenuItem
            // 
            this.demoProgramVerToolStripMenuItem.Name = "demoProgramVerToolStripMenuItem";
            this.demoProgramVerToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.demoProgramVerToolStripMenuItem.Text = "Demo Program Ver.";
            // 
            // libraryVerToolStripMenuItem
            // 
            this.libraryVerToolStripMenuItem.Name = "libraryVerToolStripMenuItem";
            this.libraryVerToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.libraryVerToolStripMenuItem.Text = "Library Ver.";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 5;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.875F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.125F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 194F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tableLayoutPanel7.Controls.Add(this.button1, 4, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.LightGreen;
            this.button1.FlatAppearance.BorderSize = 3;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(72, 33);
            this.button1.Name = "button1";
            this.tableLayoutPanel7.SetRowSpan(this.button1, 2);
            this.button1.Size = new System.Drawing.Size(126, 33);
            this.button1.TabIndex = 8;
            this.button1.Text = "Clear Result";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.button2.Location = new System.Drawing.Point(-212, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(162, 1);
            this.button2.TabIndex = 8;
            this.button2.Text = "Clear Buffer";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 5;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.875F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.125F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 194F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tableLayoutPanel9.Controls.Add(this.button3, 4, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel9.TabIndex = 0;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.BackColor = System.Drawing.Color.LightGreen;
            this.button3.FlatAppearance.BorderSize = 3;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(72, 33);
            this.button3.Name = "button3";
            this.tableLayoutPanel9.SetRowSpan(this.button3, 2);
            this.button3.Size = new System.Drawing.Size(126, 33);
            this.button3.TabIndex = 8;
            this.button3.Text = "Clear Result";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.button4.Location = new System.Drawing.Point(389, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(162, 1);
            this.button4.TabIndex = 8;
            this.button4.Text = "Clear Buffer";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 5;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.875F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.125F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 194F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tableLayoutPanel10.Controls.Add(this.button5, 4, 0);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.BackColor = System.Drawing.Color.LightGreen;
            this.button5.FlatAppearance.BorderSize = 3;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(72, 33);
            this.button5.Name = "button5";
            this.tableLayoutPanel10.SetRowSpan(this.button5, 2);
            this.button5.Size = new System.Drawing.Size(126, 33);
            this.button5.TabIndex = 8;
            this.button5.Text = "Clear Result";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.button6.Location = new System.Drawing.Point(389, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(162, 1);
            this.button6.TabIndex = 8;
            this.button6.Text = "Clear Buffer";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(871, 634);
            this.Controls.Add(this.tableLayoutPanel_menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "HKRAR-EM02 Demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel_TagList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel_menuStrip.ResumeLayout(false);
            this.tableLayoutPanel_menuStrip.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox_comport;
        private System.Windows.Forms.RadioButton rbCom;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Timer timerHealth;
        private System.Windows.Forms.Timer timerUI;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbTag;
        private System.Windows.Forms.TextBox tbGain;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox tbAtag;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnGetReaderStatus;
        private System.Windows.Forms.Button btnSetReaderTime;
        private System.Windows.Forms.Button btnSetReqMode;
        private System.Windows.Forms.Button btnSetReaderMode;
        private System.Windows.Forms.Button btnGetSn;
        private System.Windows.Forms.Button btnResetReader;
        private System.Windows.Forms.Button btnSetHB;
        private System.Windows.Forms.ComboBox cbRequestMode;
        private System.Windows.Forms.ComboBox cbReaderMode;
        private System.Windows.Forms.CheckBox cbSystemTime;
        private System.Windows.Forms.TextBox tbReaderTime;
        private System.Windows.Forms.TextBox tbEM02Result;
        private System.Windows.Forms.CheckBox cbHeartBeat;
        private System.Windows.Forms.CheckBox cbAutoGetStatus;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_menuStrip;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_TagList;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem serialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tCPToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbReturnNum;
        private System.Windows.Forms.RadioButton rbTcp;
        private System.Windows.Forms.TextBox tbHostName;
        private System.Windows.Forms.ToolStripMenuItem connectionTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem versionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem modeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem demoProgramVerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem libraryVerToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button btnClearBuffer;
        private System.Windows.Forms.Button btnGetNClaer;
        private System.Windows.Forms.Button btnGetTagBuffer;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox setVal3;
        private System.Windows.Forms.CheckBox setVal2;
        private System.Windows.Forms.CheckBox setVal1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox setValMask3;
        private System.Windows.Forms.CheckBox setValMask2;
        private System.Windows.Forms.CheckBox setValMask1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox setDir3;
        private System.Windows.Forms.CheckBox setDir2;
        private System.Windows.Forms.CheckBox setDir1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox setDirMask3;
        private System.Windows.Forms.CheckBox setDirMask2;
        private System.Windows.Forms.CheckBox setDirMask1;
        private System.Windows.Forms.Button btnSetGPIOVal;
        private System.Windows.Forms.Button btnGPIODir;
        private System.Windows.Forms.ComboBox cbSampleTime;
        private System.Windows.Forms.Button btnSetSampleTime;
        private System.Windows.Forms.ComboBox cbReaderFrequency;
        private System.Windows.Forms.ComboBox cbReaderChannel;
        private System.Windows.Forms.Button btnSetReaderFrequency;
        private System.Windows.Forms.Button btnSetReaderChannel;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnGetReaderVersion;
        private System.Windows.Forms.Button btnConn;
        private System.Windows.Forms.Button btnReaderBuzzer;
        private System.Windows.Forms.Button btnReaderLED;
        private System.Windows.Forms.Button btnLEDBuzzer;
        private System.Windows.Forms.Button btnGetSecuredSN;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
    }
}

